const String homeGeofenceKey = 'homeGeofence';
const String userUuidKey = 'uuid';
const int maxDailyMinutes = 1440;
const int kMaxAccuracy = 500;
