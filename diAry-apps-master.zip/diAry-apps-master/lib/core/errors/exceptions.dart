class ConflictDay implements Exception {}

class UnprocessableEntity implements Exception {}
