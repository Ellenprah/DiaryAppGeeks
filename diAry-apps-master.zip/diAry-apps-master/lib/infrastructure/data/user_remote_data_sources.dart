/*
import 'dart:convert';

import 'package:diary/domain/entities/daily_stats.dart';
import 'package:diary/domain/entities/daily_stats_response.dart';
import 'package:diary/core/errors/exceptions.dart';
import 'package:diary/keys.dart';
import 'package:http/http.dart' as http;

abstract class UserRemoteDataSources {

}

class UserRemoteDataSourcesImpl extends UserRemoteDataSources {

}
*/
