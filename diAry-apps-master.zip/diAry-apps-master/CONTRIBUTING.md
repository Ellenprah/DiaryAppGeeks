# Contributing

Suggestions, comments, and pull requests are very welcome!

Check out the public [list of open issues](https://github.com/digit-srl/diAry-apps/issues) or submit your own.
Issues can be used also for discussion.
Submit a pull request from your fork of the repository in order to contribute.

A full roadmap and development plan will be defined in the future.
